<?php

echo <<<EOD

<table width="100%" cellpadding="1" border="0" bgcolor="#dcdcdc" align="center">
        <tbody>
            <tr>
                <td align="center"><b>Custom Plugins Dashboard</b></td>
            </tr>
        </tbody>
</table>

EOD;



