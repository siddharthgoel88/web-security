<?php
//Should not access this location. Redirect to main Squirrel Mail page
header("Location:../../index.php"); 
?>