<?php
/*******************************************************************************

    Author ......... Pranav Cavatur
    Contact ........ pranav@pranavpc.com
    Home Site ...... http://www.pranavpc.com
    Program ........ Google Integration
    Version ........ 0.1
    Purpose ........ Importing Contacts from Google & updating Google Calender

*******************************************************************************/

//Define the Globals here

//Google App Globals
  $client_id = "351750094524-8csrb8bnlumptmqqn30cimfs0o52j81d.apps.googleusercontent.com"; //your client id
  $client_secret = "WjtfoJDWS2yadYe3k0prB5ik"; //your client secret
  $redirect_uri = "https://localhost/plugins/google_intg/google_intg.php";
  $developer_key = "AIzaSyDPTTtlK6oUlfGMpgphtwlgE41rrinu7rI";
?>